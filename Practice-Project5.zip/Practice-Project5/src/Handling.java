class CustomException extends Exception {
   
    CustomException(String message) {
        super(message);
    }
}

public class Handling{
  
    static void methodWithCheckedException() throws CustomException {
        System.out.println("Inside methodWithCheckedException");
        throw new CustomException("This is a custom checked exception");
    }

   
    static void methodWithUncheckedException() {
        System.out.println("Inside methodWithUncheckedException");
        throw new IllegalArgumentException("This is an unchecked exception");
    }

    public static void main(String[] args) {
        try {
         
            methodWithCheckedException();
        } catch (CustomException e) {
           
            System.out.println("Caught CustomException: " + e.getMessage());
        } finally {
            
            System.out.println("Finally block - Cleanup code can go here.");
        }

        try {
           
            methodWithUncheckedException();
        } catch (IllegalArgumentException e) {
           
            System.out.println("Caught IllegalArgumentException: " + e.getMessage());
        } finally {
          
            System.out.println("Finally block - Cleanup code can go here.");
        }
    }
}
