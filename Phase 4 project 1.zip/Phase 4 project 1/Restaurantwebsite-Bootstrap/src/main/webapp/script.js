// Smooth scrolling for anchor links
$(document).ready(function() {
    $("a").on('click', function(event) {
        if (this.hash !== "") {
            event.preventDefault();
            var hash = this.hash;
            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 800, function(){
                window.location.hash = hash;
            });
        }
    });
});

// Form submission handling
$(document).ready(function() {
    $("form").submit(function(event) {
        event.preventDefault();
        var name = $("#name").val();
        var email = $("#email").val();
        var message = $("#message").val();

        // You can perform additional validation here

        // For demonstration purposes, log the form data
        console.log("Name: " + name);
        console.log("Email: " + email);
        console.log("Message: " + message);

        // You can send the form data to the server using AJAX
        // Implement your server-side logic for form submission
    });
});

// Bestsellers Carousel
$(document).ready(function() {
    $('.bestsellers-carousel').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        dots: true,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 576,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    });
});
