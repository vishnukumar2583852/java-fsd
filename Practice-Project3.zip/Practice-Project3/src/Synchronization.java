class SharedResource {
    private int counter = 0;

    // Synchronized method to increment the counter
    synchronized void increment() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " : " + (++counter));
            try {
                Thread.sleep(200); // Simulating some work
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class IncrementThread extends Thread {
    private SharedResource sharedResource;

    IncrementThread(SharedResource sharedResource, String name) {
        super(name);
        this.sharedResource = sharedResource;
    }

    @Override
    public void run() {
        sharedResource.increment();
    }
}

public class Synchronization {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();

        // Creating multiple threads that share the same resource
        Thread thread1 = new IncrementThread(sharedResource, "Thread 1");
        Thread thread2 = new IncrementThread(sharedResource, "Thread 2");
        Thread thread3 = new IncrementThread(sharedResource, "Thread 3");

        // Starting the threads
        thread1.start();
        thread2.start();
        thread3.start();
    }
}
