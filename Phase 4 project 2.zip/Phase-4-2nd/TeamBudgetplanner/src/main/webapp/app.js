// Sample team data
let teamBudget = 0;
let teamDetails = [];

function addDeal(dealName, expense) {
    // Add a deal to the team details
    teamDetails.push({ dealName, expense });

    // Update the team budget
    teamBudget += expense;

    // Log the updated details
    console.log(`Deal added: ${dealName}, Expense: $${expense}`);
    console.log(`Team Budget: $${teamBudget}`);
}

function viewTeamDetails() {
    // Display the team details
    console.log("Team Details:");
    teamDetails.forEach((deal, index) => {
        console.log(`${index + 1}. ${deal.dealName} - $${deal.expense}`);
    });
    console.log(`Total Team Budget: $${teamBudget}`);
}

// Example usage
addDeal("Vendor 1 Contract", 5000);
addDeal("Vendor 2 Services", 8000);
viewTeamDetails();
